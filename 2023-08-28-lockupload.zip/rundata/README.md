Run data will be stored in this folder by default. When you are finished 
collecting and uploading data, you can run archive.py to create a .zip file of 
the intermediate data files, as well as the final result. This practice is 
recommended, so that previous data can be examined if errors in code or 
inconsistencies in data are later discovered.